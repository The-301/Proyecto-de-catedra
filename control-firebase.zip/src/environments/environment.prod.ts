export const environment = {
  firebase: {
    projectId: 'control-medicine-d01a3',
    appId: '1:1055670619449:web:cb0ee2224e840cf98cace8',
    storageBucket: 'control-medicine-d01a3.appspot.com',
    apiKey: 'AIzaSyCEq-smuxy-kSiVqeoSdmEXsEKeD60mzpk',
    authDomain: 'control-medicine-d01a3.firebaseapp.com',
    messagingSenderId: '1055670619449',
    measurementId: 'G-PEWYWCB23D',
  },
  production: true
};
