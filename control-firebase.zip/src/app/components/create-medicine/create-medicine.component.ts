import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-medicine',
  templateUrl: './create-medicine.component.html',
  styleUrls: ['./create-medicine.component.css']
})
export class CreateMedicineComponent implements OnInit {
  createMedicine: FormGroup;
  submitted = false;; 

  constructor(private fb: FormBuilder) {
    this.createMedicine = this.fb.group({
      codigo: ['',Validators.required],
      medicamento: ['', Validators.required],
      dosis: ['', Validators.required],
      horario: ['', Validators.required],
      funcion: ['', Validators.required]
    })

   }

  ngOnInit(): void {
  }
//Metodos de creacion 
  agregarMedicina(){
    this.submitted = true;

    if(this.createMedicine.invalid){
      return;
    }
    console.log(this.createMedicine);
  }

}
